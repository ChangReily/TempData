#include "at24c.h"
#include "X_02.h"
#include "ms.h"	

u32 type_Ni,type_NN,EN_AT24,adda_ix,KESS;
u8 DATA_AT;
//////////////////////////////////////////////////////////////////////////////////
//�޸�����:2012/9/9
//�汾��V1.0	  
//////////////////////////////////////////////////////////////////////////////////
//��ʼ��AT24Cxx

void ATMCxx_init(void)
{								     
 	RCC->APB2ENR|=1<<2; //ʹ������IO PORTCʱ��						 
	GPIOA->CRL&=0X000FFFFF;//PA7��©���	 PA5/6�������
	GPIOA->CRL|=0X62200000;//
	delay_us(20);	
	SDA_AA=1; 	
	ATMCxx_i();							  			
}
void AT24Cxx(void)
{
	if(EN_AT24)
	{
	    EN_AT24=0;
		switch(type_NN)
		{
			case 0:ATMCxx(Adds_QQ,QQ,0,0,0);break;
			default:break;
		}
	}
} 
void ATMCxx_i(void)
{
	u32 ii32,ii34;
	u32 SEN0=0;
////
	WP_A=0;
	delay_ms(200);
	SEN0=MMA32(Adds_i);
	if(SEN0!=AT24_i)
	{
		delay_ms(200);
		SEN0=MMA32(Adds_i);
	}
	if(SEN0!=AT24_i)
	{
		ATMCxx(Adds_QQ,QQ_ii,0,0,0);
		ATMCxx(Adds_i,0,AT24_i,0,4);//��ʼ��ʶ��
	}
	QQ=MMA8(Adds_QQ);
}
u8  MMA8(u32 register_i)
{
	u8 SEN_ii;
	MMA_R(ads_atm,register_i,0);
	SEN_ii=DATA_AT; 
	TES0=1;
	delay_ms(4);
	TES0=0;	
	return SEN_ii;
}
u32 MMA32(u32 register_i)
{
	u32 SEN_ii=0;
	MMA_R(ads_atm,register_i,1);
	*((char*)&SEN_ii+0)=DATA_AT;
	read_AA(1);
	*((char*)&SEN_ii+1)=DATA_AT;
	read_AA(1);
	*((char*)&SEN_ii+2)=DATA_AT;
	read_AA(0);
	*((char*)&SEN_ii+3)=DATA_AT; 
	SOP_AA(); 
	TES0=1;
	delay_ms(4);
	TES0=0;	
	return SEN_ii;
}
float MMAf(u32 register_i)
{
	float SEN_ii=0;
	MMA_R(ads_atm,register_i,1);
	*((char*)&SEN_ii+0)=DATA_AT;
	read_AA(1);
	*((char*)&SEN_ii+1)=DATA_AT;
	read_AA(1);
	*((char*)&SEN_ii+2)=DATA_AT;
	read_AA(0);
	*((char*)&SEN_ii+3)=DATA_AT; 
	SOP_AA(); 
	TES0=1;
	delay_ms(4);
	TES0=0;	
	return SEN_ii;
}
/////////////vv0:uchar,8bit;//vv2:uint,16bit;//vv4:float,32bit;
////////////vaa:��ַ��������ʵ��flash��ַ��ͬһӳ������
void ATMCxx(u32 vaa,u32 vv0,u32 vv2,float vv4,u8 m)						        
{
	u32 SEN_ii=0;	
	float SEN_i=0;
    WP_A=0;
    switch(m)
	{
	    case 0:
		    {
					SEN_ii=0;
		    	MMA_W(ads_atm,vaa,vv0,0);
					delay_ms(40);				
					MMA_R(ads_atm,vaa,0);
					SEN_ii=DATA_AT;      				       
					if(SEN_ii!=vv0)
					{
						error0|=0x20;
						vvi402=0;
						vvi502=0;
					}
					else
					{
						TES0=1;
						delay_ms(40);
						TES0=0;											
						vvi402=0;
						vvi502=0;
					}
			}
		    break;
		case 2:
		    {
					SEN_i=0;
		    	MMA_W(ads_atm,vaa,*((char*)&vv4+0),1);
					write_AA(*((char*)&vv4+1));
					write_AA(*((char*)&vv4+2));
					write_AA(*((char*)&vv4+3));
					SOP_AA();
					delay_ms(40);								
					MMA_R(ads_atm,vaa,1);
					*((char*)&SEN_i+0)=DATA_AT;
					read_AA(1);
					*((char*)&SEN_i+1)=DATA_AT;
					read_AA(1);
					*((char*)&SEN_i+2)=DATA_AT;
					read_AA(0);
					*((char*)&SEN_i+3)=DATA_AT; 
					SOP_AA();    				       
					if(SEN_i!=vv4)
					{
						error0|=0x20;
						vvi402=0;
						vvi502=0;
					}
					else
					{
						TES0=1;
						delay_ms(40);
						TES0=0;		
						vvi402=0;
						vvi502=0;					
					}
			}
		    break;
		case 4:
		   {
					SEN_ii=0;
		    	MMA_W(ads_atm,vaa,*((char*)&vv2+0),1);
					write_AA(*((char*)&vv2+1));
					write_AA(*((char*)&vv2+2));
				  write_AA(*((char*)&vv2+3));
					SOP_AA();
					delay_ms(40);				
					MMA_R(ads_atm,vaa,1);
	        *((char*)&SEN_ii+0)=DATA_AT;
					read_AA(1);
					*((char*)&SEN_ii+1)=DATA_AT; 
					read_AA(1);
					*((char*)&SEN_ii+2)=DATA_AT; 
				  read_AA(0);
					*((char*)&SEN_ii+3)=DATA_AT; 
					SOP_AA();					
					if(SEN_ii!=vv2)
					{
						error0|=0x20;
						vvi402=0;
						vvi502=0;
					}
					else
					{
						TES0=1;
						delay_ms(40);
						TES0=0;
						vvi402=0;
						vvi502=0;
					}
				}
		    break;
		default:break;
	}													  
    WP_A=1;			 
}			   
void MMA_W(u32 Device_ads,u32 register_i,u8 data_i,u8 sop)
{    
		SAT_AA();
		write_AA(Device_ads);						 
		write_AA(register_i/0x100);
		write_AA(register_i%0x100);
		write_AA(data_i);
		if(!sop)					    
			SOP_AA();
}
void MMA_R(u32 Device_ads,u32 register_i,u8 data_ack)
{   
		SAT_AA();
		write_AA(Device_ads);			 
		write_AA(register_i/0x100);
		write_AA(register_i%0x100);
		SAT_AA();
		write_AA(Device_ads+1);						 
		read_AA(data_ack);
		if(!data_ack)
			SOP_AA();
}
void write_AA(u8 yye)							   	////////////////////////////////////////////
{
   u32 ii24;
   for(ii24=0;ii24<8;ii24++)
   {
   	  SDA_AA=!!(yye&0x80);
			delay_us(20);
			yye<<=1;
			SCL_AA=1;
			delay_us(20);
			SCL_AA=0;
			delay_us(20);
   }
   SCL_AA=1;
   delay_us(20);
   SCL_AA=0;
}	  		
void read_AA(u8 i_ack)
{
   u32 ii24;
   DATA_AT=0;      
   SDA_AA=1;
   for(ii24=0;ii24<8;ii24++)
   {
   	  SCL_AA=1;
			DATA_AT<<=1;
			delay_us(20);
			if(SDA_IN)
			DATA_AT++;	  
			SCL_AA=0;
			delay_us(20);
   }
   SDA_AA=!i_ack;
   delay_us(20);
   SCL_AA=1;
   delay_us(20);
   SCL_AA=0;
}
void SAT_AA(void)
{
   SCL_AA=0;
   delay_us(20);
   SDA_AA=1;
   delay_us(20);
   SCL_AA=1;
   delay_us(20);						
   SDA_AA=0;
   delay_us(20);
   SCL_AA=0;
   delay_us(20);
}
void SOP_AA(void)
{
   SCL_AA=0;
   delay_us(20);
   SDA_AA=0;
   delay_us(20);
   SCL_AA=1;
   delay_us(20);
   SDA_AA=1;
   delay_us(20);
}							 											   	 
									 



























