#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"
#include "X_02.h"
//////////////////////////////////////////////////////////////////////////////////	 
//All rights reserved									  
//////////////////////////////////////////////////////////////////////////////////   	 

#define KEYN_i 10		//�ؼ�����ʱ�� 0.1*N .S

#define KEY0 PAin(7) 
#define KEY1 PAin(6)	 
#define KEY2 PAin(5)	

extern u32 	 Key_v,Key_i,Key_ii,Key_N,Key_N2;
void KEY_Init(void);//IO��ʼ��
void KKi(void);
u8 KEY_Scan(void);  	//����ɨ�躯��	
u32 SET_vx2(u32 Nx,u32 Cx,u32 da2);
float SET_vx4(u32 Nx,float da4);


#endif











