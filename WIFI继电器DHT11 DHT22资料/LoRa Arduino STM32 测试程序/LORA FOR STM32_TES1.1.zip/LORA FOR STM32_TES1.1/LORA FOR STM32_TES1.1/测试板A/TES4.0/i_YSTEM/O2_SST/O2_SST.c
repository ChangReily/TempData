#include "sys.h"
#include "O2_SST.h"
#include "EE32.h"
#include "exti.h"
#include "at24c.h"
#include "X_02.h"
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//M2_vvi/��Ч����֡����ʱ�����ֵ��
//M2_i/����������ű�־��
//M2_ii/����������ű�־
//M2_v/��������λ�ο���־��
//M2_v2/��������λ�ο���־��
//M2_w/���Ϳ�ʼ��־,==1׼��,==2��ʼ��

u8  O2_M,Aser_M4,M4_DATA,M4_writeDat,M4_readDat[M4_REN];
u32 M4_vvi,M4_i,M4_c,M4_ii,M4_v,M4_v2,M4_Ti,M4_Ri;
float O2_M4;

void M4_SRT_init(void)
{
	M4_RXN=1;
	M4_TX=1;
	
	O2_M=0;
	Aser_M4=0;
	M4_vvi=0;
	M4_c=0;
	M4_i=0;
	M4_ii=0;
	M4_v=0;
	M4_v2=0;
	M4_Ti=0;
	M4_Ri=0;
}
void M4_O2_SST(void)
{
	if(O2_M!=1)
		M4_AAT(ASC_M,1,1);		//MODE 1 POLL
	else
	{
		M4_AAT(ASC_O,0,0);
		M4_AAR();
	}
}
void M4_AAT(u8 ASK_MX,u32 DATA_MX,u8 DATA_N)			//����һ������֡
{
	if(M4_Ti)
		{						
			if(!M4_v2)
			{
				switch(M4_ii)
				{				
					case 0:			//�������� X?
						{
							M4_writeDat=ASK_MX;
						}
						break;
					case 1:			//���Ϳո�� SPACE
						{
							M4_writeDat=ASC_space;
						}
						break;
					case 2:			//��������1
						{
							M4_writeDat=ASC_num+DATA_MX%10000/1000;
						}
						break;
					case 3:			//��������2
						{
							M4_writeDat=ASC_num+DATA_MX%1000/100;
						}
						break;
					case 4:			//��������3
						{
							M4_writeDat=ASC_num+DATA_MX%100/10;
						}
						break;
					case 5:			//��������4
						{
							M4_writeDat=ASC_num+DATA_MX%10;
						}
						break;
					case 6:			//����CR
						{
							M4_writeDat=ASC_CR;
						}
						break;
					case 7:			//����LF
						{
							M4_writeDat=ASC_LF;
						}
						break;
						default:break;
				}
			}
			switch(M4_v2)
			{
				case 0:			//9600/������ʼλ0
					{
						M4_TX=0;
					}
					break;
				case 4:			//9600/��������λ 0X01
					{
						if(M4_writeDat&0x01)
						M4_TX=1;
						else
						M4_TX=0;	
					}
					break;
				case 8:			//9600/��������λ 0X02
					{
						if(M4_writeDat&0x02)
						M4_TX=1;
						else
						M4_TX=0;	
					}
					break;
				case 12:			//9600/��������λ 0X04
					{
						if(M4_writeDat&0x04)
						M4_TX=1;
						else
						M4_TX=0;	
					}
					break;
				case 16:			//9600/��������λ 0X08
					{
						if(M4_writeDat&0x08)
						M4_TX=1;
						else
						M4_TX=0;	
					}
					break;
				case 20:			//9600/��������λ 0X10
					{
						if(M4_writeDat&0x10)
						M4_TX=1;
						else
						M4_TX=0;	
					}
					break;
				case 24:			//9600/��������λ 0X20
					{
						if(M4_writeDat&0x20)
						M4_TX=1;
						else
						M4_TX=0;	
					}
					break;
				case 28:			//9600/��������λ 0X40
					{
						if(M4_writeDat&0x40)
						M4_TX=1;
						else
						M4_TX=0;	
					}
					break;
				case 32:			//9600/��������λ 0X80
					{
						if(M4_writeDat&0x80)
						M4_TX=1;
						else
						M4_TX=0;	
					}
					break;
				case 36:			//9600/����ֹͣλ1
					{
						M4_TX=1;						
						M4_ii++;
						if(DATA_N&&M4_ii==2)
						{
							M4_ii=6-DATA_N;
						}
						if(M4_writeDat==ASC_LF)
						{
							M4_ii=0;
							M4_Ti=0;	
							M4_i=0;
							M4_c=0;
							Aser_M4=1;
							vvi405=0;
						}					
					}
					break;
				default:break;
			}
			if(M4_v2<64)
			M4_v2++;
			else
			M4_v2=0;	
		}
}
void M4_AAR(void)
{
	if(M4_Ri)
		{																																	
			M4_Ri=0;
			if(M4_readDat[0]==ASC_O)
				O2_M4=(M4_readDat[2]-ASC_num)*1000+(M4_readDat[3]-ASC_num)*100+(M4_readDat[4]-ASC_num)*10+(M4_readDat[5]-ASC_num)+0.1*(M4_readDat[7]-ASC_num);
			if(M4_readDat[0]==ASC_M)
				O2_M=M4_readDat[3]-ASC_num;
			for(x401=0;x401<M4_REN;x401++)
			{
				M4_readDat[x401]=0;
			}
			error_i&=0xfff7;
			Aser_M4=0;
			x404=0;
		}
		//////////////////////////////////
		if(M4_c)
		{
			switch(M4_v)
				{
					case 6:			//9600_OX01BIT
						{
							if(M4_RX)
							M4_DATA|=0x01;
						}
						break;
					case 10:			//9600_OX02BIT
						{
							if(M4_RX)
							M4_DATA|=0x02;
						}
						break;
					case 14:		//9600_OX04BIT
						{
							if(M4_RX)
							M4_DATA|=0x04;
						}
						break;
					case 18:		//9600_OX08BIT
						{
							if(M4_RX)
							M4_DATA|=0x08;
						}
						break;
					case 22:		//9600_OX10BIT
						{
							if(M4_RX)
							M4_DATA|=0x10;
						}
						break;
					case 26:		//9600_OX20BIT
						{
							if(M4_RX)
							M4_DATA|=0x20;
						}
						break;
					case 30:		//9600_OX40BIT
						{
							if(M4_RX)
							M4_DATA|=0x40;
						}
						break;
					case 34:		//9600_OX80BIT
						{
							if(M4_RX)
							M4_DATA|=0x80;
						}
						break;
					case 38:		//9600_ֹͣλ
						{
							M4_c=0;		//������ձ�־							
							if(M4_RX)
							{
								if(!M4_i||M4_readDat[0]==ASC_O||M4_readDat[0]==ASC_M)
								{			
									M4_vvi=0;
									M4_readDat[M4_i]=M4_DATA;
									if(M4_readDat[M4_i]==ASC_LF)		//���һ������֡��ȡ 
									{
										M4_Ri=1;			//��λ֡������ɱ�־
									}
									if(M4_i<20)
									M4_i++;
								}		
							}
						}
						break;
						default:break;
				}
				if(M4_v<64)
				M4_v++;
				else
				M4_v=0;
		}
}
























