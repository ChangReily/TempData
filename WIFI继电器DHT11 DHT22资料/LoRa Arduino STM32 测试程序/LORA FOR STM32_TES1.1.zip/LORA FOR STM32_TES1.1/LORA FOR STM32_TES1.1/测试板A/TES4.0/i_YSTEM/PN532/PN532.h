#ifndef __PN532_H
#define __PN532_H
#include "sys.h"

//115200 8bit 1stop 0pe
#define USART_REC_LEN02   	64				//���ܴ洢USART_REC_LEN02���ֽ�

#define ZNN02			        7						//������  0/1200,1/2400/2/4800,3/9600,4/14400,5/19200,6/57600,7/115200
#define ZEE02			        0						//��żУ��  0/��,1/��,2/ż

static const u8 table_WAUP[]=//24LENN
{
0x55,0x55,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF,0x03,0XFD,0XD4,0X14,0X01,0X17,0X00,
};
static const u8 table_IDD1[]=//11LENN
{
0x00,0X00,0XFF,0X04,0XFC,0XD4,0X4A,0X01,0X00,0XE1,0X00,
};
static const u8 table_IDD2[]=//11LENN
{
0x00,0X00,0XFF,0X04,0XFC,0XD4,0X4A,0X02,0X00,0XE0,0X00,
};
extern u32 i02,ii02,vvi02,vvi202,ZZ_i,IDD_i;
extern u8  X02,writeDat02,readDat02[USART_REC_LEN02]; //���ջ���,���USART_REC_LEN02���ֽ�.


void Ci02(void);
void usart02_init(u32 pclk2,u32 bound,u32 PSEE);
void PN532_int(void);
void PN532(void);
void WAUP(void);
void IDD(void);
void DATA_Fss02(u8 DATA0);
void DATA_Pss02(void);













#endif
















