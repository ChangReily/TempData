#ifndef __SHT2XX_H
#define __SHT2XX_H
#include "sys.h"
#include "EE32.h"


#define SDA_sht	EEOUT1		//SHT2xx SDA  �ӿ�E1
#define SDAA_sht	EEIN1
#define SCL_sht	EEOUT2	  //SHT2xx SCL  �ӿ�E2
#define SCLA_sht	EEIN2

#define ADDS_SHT  0X80			//SHT2X IIC��ַ
#define TEES_SHT  0XE3			//�¶Ȳ���
#define HEES_SHT  0XE5			//ʪ�Ȳ���

void SHT2X_int(void);
void SHT2X_EE(void);				 //SHT2x������
void SHT2x(u8 yi);           //SHT2x�Ӻ���
void write_sht(u8 yii);	   	//IIC_WRITE
void read_sht(u8 x_ack);		                
void SAT_sht(void);				       	            
void SOP_sht(void);					   	            
void soft_rest_sht(void);
void crc_8(void);			   		//CRC-8У���Ӻ���,����ʽΪ��P(x)=x^8+x^5+x^4+1=100110001=0x131;

extern float HUMIE,TEMP;


#endif



















