#include "key.h"
#include "delay.h"
#include "X_02.h"
//////////////////////////////////////////////////////////////////////////////////	 
//All rights reserved									  
//////////////////////////////////////////////////////////////////////////////////  

u32 		Key_v=0,Key_i=0,Key_ii=0,Key_N=0,Key_N2=0;//Key_v/���������; Key_i/������Ч��־ ִ�к�����; Key_ii/������λ��־ ��λ����; Key_N/�ػ���ִ��ʱ��
//������ʼ������
void KEY_Init(void)
{
	RCC->APB2ENR|=1<<2;     //ʹ��PORTAʱ��   
	GPIOA->CRL&=0X000FFFFF;	//����PA5~7/��������
	GPIOA->CRL|=0X88800000; 	
	GPIOA->ODR|=7<<5;  
} 
u8 KEY_Scan(void)
{	 
	u32 Key_vx;
		LEX_i=1;
		BE_EN0=1;
		vvi402=0;
		vvi502=0;//������Ӧ 0.1S
		Key_vx=0;
		Key_vx|=!KEY0+(!KEY1)*2+(!KEY2)*4;
		Key_i=1;
		Key_ii=1;
		////
		if(BATTERY5<20)	
		vvi600=40;
		else
		vvi600=0;
	return Key_vx;
}
void KKi(void)
{
	u32 ii602,ii604,ii606;
	if(Key_i)
	{
		switch(Dis_i)
		{
			case 0:
			{
				switch(Key_v)
				{
					case 1:
					{
						Dis_i++;
						SET_N=0;
						SET_Ni=3;
						if(CC)//�����ؿ�
						{
							CC=0;
							CCx=CCx4;
						}
					}
					break;
					case 2:
					{
						if(SENSOR_c>0.2)
						{
							ZEROSET_v();						
						}
						if(CC)//�ؿ�����
						{
							if(CCx<31)//�ؿ��ڲ�ָ��
							CCx++;
							else
								CCx=0;
						}
						////
						if(CCx7)//�ؿ���ʾָ��
						CCx7--;
						else
							CCx7=31;
					}
					break;				
					case 4://�ؿ�����
					{							
						if(CCx7<31)//�ؿ���ʾָ��
						CCx7++;
						else
							CCx7=0;
						////
						if(CCx)//�ؿ��ڲ�ָ��
						CCx--;
						else
							CCx=31;
						////
						if(!CC)//�ؿ���ʼ
						{
							CC=1;
							CCx7=0;
						}
					}
					break;
					default:break;
				}			
			}
			break;	
			case 1:
			{
				switch(Key_v)
				{
					case 1:
					{
						Dis_i++;
						SED_N=0;
						SET_v2=0;
						SET_v4=0;			
						switch(SET_N)//SET_vxλ������
						{
							case 0:ii602=0;ii604=0;ii606=2;break;//
							case 1:ii602=6;ii604=0;ii606=1;break;//
							case 3:Dis_i=0;break;//
							default:Dis_i=0;break;
						}
						//PHSET ZERO/VSET 2
							
						SED_Ni=ii602;SET_vi=ii604;SET_vii=ii606;
					}
					break;
					case 2:
					{
						if(SET_N<SET_Ni)
						SET_N++;
						else
						SET_N=0;
					}
					break;
					case 4:
					{
						Dis_i--;
					}
					break;
					default:break;
				}
			}
			break;
			case 2:
			{
				switch(Key_v)
				{
					case 6:
					{
						switch(SET_N)//SET_vxλ������
						{
							case 0:ZEROSET_PH();break;//
							case 1:CASSET_PH(SENSOR_v,SET_v4);break;//
							default:ii602=0;break;
						}						
						//PHSET ZERO/VSET 2		
						Dis_i--;						
					}
					break;
					case 1:
					{
						if(SED_N<SED_Ni)
						SED_N++;
						else
						SED_N=0;
					}
					break;
					case 2:
					{
						if(SET_vii==0)
						SET_v2=SET_vx2(SED_N,SET_vi,SET_v2);
						if(SET_vii==1)
						SET_v4=SET_vx4(SED_N,SET_v4);
					}
					break;
					case 4:
					{
						Dis_i--;
					}
					break;
					default:break;
				}
			}
			break;
			default:break;
		}
		Key_i=0;
		Dis_Mi=1;
		vvi506=0;
	}
}
u32 SET_vx2(u32 Nx,u32 Cx,u32 da2)
{
	switch(Nx)
	{
		case 0:
		{
			if(da2%10<Cx)
				da2++;
			else
				da2=0;
		}
		break;	
		default:break;
	}
	return da2;
}
float SET_vx4(u32 Nx,float da4)//ֵ�趨
{
	u32 dax,z_i;
	float da4x;
	if(da4<0)
	{
		z_i=0;
	}
	else
	{
		z_i=1;
	}
	da4*=100;
	dax=fabs((float)da4);//ȡda4����ֵ
	switch(Nx)
	{
		case 0:
		{
			if(dax%10<9)
				dax++;
			else
				dax-=9;
		}
		break;
		case 1:
		{
			if(dax%100/10<9)
				dax+=10;
			else
				dax-=90;
		}
		break;
		case 2:
		{
			if(dax%1000/100<9)
				dax+=100;
			else
				dax-=900;
		}
		break;
		case 3:
		{
			if(dax%10000/1000<9)
				dax+=1000;
			else
				dax-=9000;
		}
		break;
		case 4:
		{
			if(dax%100000/10000<9)
				dax+=10000;
			else
				dax-=90000;
		}
		break;
		case 5:
		{
			if(dax%1000000/100000<9)
				dax+=100000;
			else
				dax-=900000;
		}
		break;
		case 6:
		{
			z_i^=1;
		}
		break;
		default:break;
	}
		da4x=dax*1.0/100;
	if(!z_i)
		da4x*=-1;
	return da4x;
}



















