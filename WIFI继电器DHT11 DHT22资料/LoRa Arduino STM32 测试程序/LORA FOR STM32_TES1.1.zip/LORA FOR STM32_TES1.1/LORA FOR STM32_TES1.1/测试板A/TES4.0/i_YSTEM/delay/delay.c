#include "delay.h"
#include "sys.h"
#include "X_02.h"

//��ʱnus
//nusΪҪ��ʱ��us��.		    								   
void delay_us(u32 nus)
{		
	u32 temp,temp2;	    	 
	for(temp=0;temp<nus;temp++)
	{
		for(temp2=0;temp2<10;temp2++)
		{}
	}
}
//��ʱnms
void delay_ms(u32 nms)
{	 		  	  
	u32 temp,temp2;		   
	for(temp=0;temp<nms;temp++)
	{
		for(temp2=0;temp2<10;temp2++)
		{
			delay_us(100);
		}
	}
} 
			 



































