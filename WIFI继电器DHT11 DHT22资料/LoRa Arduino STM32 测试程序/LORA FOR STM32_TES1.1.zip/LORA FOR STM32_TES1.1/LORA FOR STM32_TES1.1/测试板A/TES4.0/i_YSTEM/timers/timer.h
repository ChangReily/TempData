#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"


void TIM3_Int_Init(u16 arr,u16 psc);
void TIM2_Int_Init(u16 arr,u16 psc);

extern u32 vvi402,vvi2402,vvi404,vvi405,vvi406,vvi501,vvi502,vvi504,vvi506,vvi600,vvi602,vvi604,vvi606;

#endif























