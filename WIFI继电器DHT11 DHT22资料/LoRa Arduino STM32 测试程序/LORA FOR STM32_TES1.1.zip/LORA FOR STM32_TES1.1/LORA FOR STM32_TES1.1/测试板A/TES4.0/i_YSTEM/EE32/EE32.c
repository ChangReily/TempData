#include "EE32.h"
#include "X_02.h"


u32 x401,x404,x405,x406,ee20,ee22,ee24,ee25,e32_i;


void init_ee32(void)						//ȫ����©�������
{
	RCC->APB2ENR|=1<<2;//����A
	RCC->APB2ENR|=1<<3;//����B
	RCC->APB2ENR|=1<<4;//����C
	RCC->APB2ENR|=1<<5;//����D
	RCC->APB2ENR|=1<<6;//����E
	GPIOA->CRL&=0X0000FFFF;	
	GPIOA->CRL|=0X66660000;
	GPIOB->CRL&=0XFFFFFF00;	
	GPIOB->CRL|=0X00000066;
	GPIOB->CRH&=0X0000FFFF;	
	GPIOB->CRH|=0X66660000;
	GPIOC->CRL&=0X0000FFFF;	
	GPIOC->CRL|=0X66660000;
	GPIOC->CRH&=0XFFFFFF00;	
	GPIOC->CRH|=0X00000066;
	GPIOD->CRH&=0X00000000;	
	GPIOD->CRH|=0X66666666;
	GPIOE->CRH&=0X00000000;	
	GPIOE->CRH|=0X66666666;
	//
	delay_us(40);
	//
	EEOUT1=1;
	EEOUT2=1;
	EEOUT3=1;
	EEOUT4=1;
	EEOUT5=1;
	EEOUT6=1;
	EEOUT7=1;
	EEOUT8=1;
	EEOUT9=1;
	EEOUT10=1;
	EEOUT11=1;
	EEOUT12=1;
	EEOUT13=1;
	EEOUT14=1;
	EEOUT15=1;
	EEOUT16=1;
	//
	EEOUT17=1;
	EEOUT18=1;
	EEOUT19=1;
	EEOUT20=1;
	EEOUT21=1;
	EEOUT22=1;
	EEOUT23=1;
	EEOUT24=1;
	EEOUT25=1;
	EEOUT26=1;
	EEOUT27=1;
	EEOUT28=1;	
	EEOUT29=1;
	EEOUT30=1;
	EEOUT31=1;
	EEOUT32=1;
	//
	x401=0;
	x404=0;
	x405=0;
	x406=0;
}
void EE_OUT(u32 EE_x,u32 data_x)
{
	switch(EE_x)
	{
		case 0:EEOUT1=!!data_x;break;
		case 1:EEOUT2=!!data_x;break;
		case 2:EEOUT3=!!data_x;break;
		case 3:EEOUT4=!!data_x;break;
		case 4:EEOUT5=!!data_x;break;
		case 5:EEOUT6=!!data_x;break;
		case 6:EEOUT7=!!data_x;break;
		case 7:EEOUT8=!!data_x;break;
		case 8:EEOUT9=!!data_x;break;
		case 9:EEOUT10=!!data_x;break;
		case 10:EEOUT11=!!data_x;break;
		case 11:EEOUT12=!!data_x;break;
		case 12:EEOUT13=!!data_x;break;
		case 13:EEOUT14=!!data_x;break;
		case 14:EEOUT15=!!data_x;break;
		case 15:EEOUT16=!!data_x;break;
		case 16:EEOUT17=!!data_x;break;
		case 17:EEOUT18=!!data_x;break;
		case 18:EEOUT19=!!data_x;break;
		case 19:EEOUT20=!!data_x;break;
		case 20:EEOUT21=!!data_x;break;
		case 21:EEOUT22=!!data_x;break;
		case 22:EEOUT23=!!data_x;break;
		case 23:EEOUT24=!!data_x;break;
		case 24:EEOUT25=!!data_x;break;
		case 25:EEOUT26=!!data_x;break;
		case 26:EEOUT27=!!data_x;break;
		case 27:EEOUT28=!!data_x;break;
		case 28:EEOUT29=!!data_x;break;
		case 29:EEOUT30=!!data_x;break;
		case 30:EEOUT31=!!data_x;break;
		case 31:EEOUT32=!!data_x;break;
		default:break;
	}
}
void EE_IN(u32 EE_x)
{
		switch(EE_x)
	{
		case 0:e32_i=EEIN1;break;
		case 1:e32_i=EEIN2;break;
		case 2:e32_i=EEIN3;break;
		case 3:e32_i=EEIN4;break;
		case 4:e32_i=EEIN5;break;
		case 5:e32_i=EEIN6;break;
		case 6:e32_i=EEIN7;break;
		case 7:e32_i=EEIN8;break;
		case 8:e32_i=EEIN9;break;
		case 9:e32_i=EEIN10;break;
		case 10:e32_i=EEIN11;break;
		case 11:e32_i=EEIN12;break;
		case 12:e32_i=EEIN13;break;
		case 13:e32_i=EEIN14;break;
		case 14:e32_i=EEIN15;break;
		case 15:e32_i=EEIN16;break;
		case 16:e32_i=EEIN17;break;
		case 17:e32_i=EEIN18;break;
		case 18:e32_i=EEIN19;break;
		case 19:e32_i=EEIN20;break;
		case 20:e32_i=EEIN21;break;
		case 21:e32_i=EEIN22;break;
		case 22:e32_i=EEIN23;break;
		case 23:e32_i=EEIN24;break;
		case 24:e32_i=EEIN25;break;
		case 25:e32_i=EEIN26;break;
		case 26:e32_i=EEIN27;break;
		case 27:e32_i=EEIN28;break;
		case 28:e32_i=EEIN29;break;
		case 29:e32_i=EEIN30;break;
		case 30:e32_i=EEIN31;break;
		case 31:e32_i=EEIN32;break;
		default:break;
	}
}












