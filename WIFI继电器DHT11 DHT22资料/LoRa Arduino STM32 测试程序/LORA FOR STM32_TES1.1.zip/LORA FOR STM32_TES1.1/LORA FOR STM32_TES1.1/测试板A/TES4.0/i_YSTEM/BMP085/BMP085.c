#include "BMP085.h"
#include "X_02.h"



///////////////////////////////////////EEX_Pa(ii%6,HRES_MODE,oss_H);

u16 UT,AC4_,AC5_,AC6_;
u8 v_mp;
s16 AC1_,AC2_,AC3_,B1_,B2_,MB_,MC_,MD_;
u32 UP;
float T_z,Pa_i;


void BMP085_init(void)							//����E2PROM�и���ϵ����176 BIT
{
	XCLR_mp=0;			//��λBM085
	  delay_us(20);
	  XCLR_mp=1;
	 delay_ms(40);
	 bmp_R(ADDRESS_mp,AM_C1>>8,0);
   *((char*)&AC1_+1)=v_mp;
   bmp_R(ADDRESS_mp,AM_C1&0xff,0);
   *((char*)&AC1_)=v_mp;
   bmp_R(ADDRESS_mp,AM_C2>>8,0);
   *((char*)&AC2_+1)=v_mp;
   bmp_R(ADDRESS_mp,AM_C2&0xff,0);
   *((char*)&AC2_)=v_mp;
   bmp_R(ADDRESS_mp,AM_C3>>8,0);
   *((char*)&AC3_+1)=v_mp;
   bmp_R(ADDRESS_mp,AM_C3&0xff,0);
   *((char*)&AC3_)=v_mp;
   bmp_R(ADDRESS_mp,AM_C4>>8,0);
   *((char*)&AC4_+1)=v_mp;
   bmp_R(ADDRESS_mp,AM_C4&0xff,0);
   *((char*)&AC4_)=v_mp;
   bmp_R(ADDRESS_mp,AM_C5>>8,0);
   *((char*)&AC5_+1)=v_mp;
   bmp_R(ADDRESS_mp,AM_C5&0xff,0);
   *((char*)&AC5_)=v_mp;
   bmp_R(ADDRESS_mp,AM_C6>>8,0);
   *((char*)&AC6_+1)=v_mp;
   bmp_R(ADDRESS_mp,AM_C6&0xff,0);
   *((char*)&AC6_)=v_mp;
   bmp_R(ADDRESS_mp,AM_B1>>8,0);
   *((char*)&B1_+1)=v_mp;
   bmp_R(ADDRESS_mp,AM_B1&0xff,0);
   *((char*)&B1_)=v_mp;
   bmp_R(ADDRESS_mp,AM_B2>>8,0);
   *((char*)&B2_+1)=v_mp;
   bmp_R(ADDRESS_mp,AM_B2&0xff,0);
   *((char*)&B2_)=v_mp;
   bmp_R(ADDRESS_mp,AM_MB>>8,0);
   *((char*)&MB_+1)=v_mp;
   bmp_R(ADDRESS_mp,AM_MB&0xff,0);
   *((char*)&MB_)=v_mp;
   bmp_R(ADDRESS_mp,AM_MC>>8,0);
   *((char*)&MC_+1)=v_mp;
   bmp_R(ADDRESS_mp,AM_MC&0xff,0);
   *((char*)&MC_)=v_mp;
   bmp_R(ADDRESS_mp,AM_MD>>8,0);
   *((char*)&MD_+1)=v_mp;
   bmp_R(ADDRESS_mp,AM_MD&0xff,0);
   *((char*)&MD_)=v_mp;
}
void EEX_Pa(u8 im,u8 MODE_i,u8 oss_i)
{
	float x1,x2,x3,B3_,B4_,B5_,B6_,B7_;
	if(!im)
	{
		BMP085_xx(MODE_i,oss_i);
		x1=(float)(UT-AC6_)*AC5_/0x8000;
		x2=(float)MC_*0x800/(x1+MD_);
		B5_=x1+x2;
		T_z=(B5_+8)/0x10;
		/////////////////////***************************************************///
		B6_=B5_-4000;
		x1=(B2_*((float)B6_*B6_/0x1000))/0x800;
		x2=(float)AC2_*B6_/0x800;
		x3= x1+x2;
		B3_=((float)(AC1_*4+x3)*pow(2,oss_i)+2)/4;
		x1=(float)AC3_*B6_/0x2000;
		x2=(B1_*((float)B6_*B6_/0x1000))/0x10000;
		x3=((x1+x2)+2)/4;
		B4_=(float)AC4_*fabs((float)(x3+32768))/0x8000;
		B7_=(float)(UP-B3_)*(50000/pow(2,oss_i));
		if(B7_<0x80000000)
		{
			Pa_i=(float)(B7_*2)/B4_;
		}
		else
		{
			Pa_i=((float)B7_/B4_)*2;
		}
		x1=(float)(Pa_i/0x100)*(Pa_i/0x100);
		x1=(float)(x1*3038)/0x10000;
		x2=(float)(-7357*Pa_i)/0x10000;
		Pa_i=Pa_i+(x1+x2+3791)/0x10;		   
	}
}
void BMP085_xx(u8 MODE_,u8 osrs_)
{	
	u16 zz_;
	UT=0;
	UP=0;
  bmp_W(ADDRESS_mp,REGIST_TES,TEM_);					  //���¶Ȳο�ֵ��UT
	EOC_AA_mp=1;
	for(zz_=0;zz_<40;zz_++)
	{
	   delay_ms(4);
	   if(EOC_IN_mp)
	   break;
	}	
	if(EOC_IN_mp)
	{
	   bmp_R(ADDRESS_mp,MSB_mp,0);					   //��UT,MSBλ��8λ
	   *((char*)&UT+1)=v_mp;
	   bmp_R(ADDRESS_mp,LSB_mp,0);					   //��UT,LSBλ��8λ
	   *((char*)&UT)=v_mp;
	}	
	bmp_W(ADDRESS_mp,REGIST_TES,MODE_+(osrs_<<6));					  //����ѹ�ο�ֵ��UP,MODE_����ģʽ������λosrs��2
	EOC_AA_mp=1;
	for(zz_=0;zz_<40;zz_++)
	{
	   delay_ms(4);
	   if(EOC_IN_mp)
	   break;
	}	
	if(EOC_IN_mp)
	{
	   bmp_R(ADDRESS_mp,MSB_mp,0);					   //��UP,MSBλ��8λ
	   *((char*)&UP+3)=v_mp;
	   bmp_R(ADDRESS_mp,LSB_mp,0);					   //��UP,LSBλ��8λ
	   *((char*)&UP+2)=v_mp;
	   bmp_R(ADDRESS_mp,XLSB_mp,0);					   //��UP,XLSBλ��osrs:2λ
	   *((char*)&UP+1)=v_mp;		
	   UP>>=(16-osrs_);							   //����λ����
		error_i&=0xffffffFD;
	}
	else 
	{
		XCLR_mp=0;			//��λBM085
	  delay_us(20);
	  XCLR_mp=1;
		error_i|=0x02;
	}
}
void bmp_W(u8 address_i,u8 register_i,u8 data_i)
{
    SAT_mp();
    write_mp(address_i);							 //��ַ0xEE,д����
    write_mp(register_i);
    write_mp(data_i);
    SOP_mp();
}
void bmp_R(u8 address_i,u8 register_i,u8 data_ack)
{
    SAT_mp();
    write_mp(address_i);						 
	write_mp(register_i);
	SAT_mp();
	write_mp(address_i|1);						 //��ַ0xEE+1,������
	read_mp(data_ack);
	SOP_mp();
}
void write_mp(u8 vvi_mp)
{
   u8 zz;
   for(zz=0;zz<8;zz++)
   {
   	  SDA_AA_mp=!!(vvi_mp&0x80);
	  vvi_mp<<=1;
		delay_us(20);
	  SCL_mp=1;
	  delay_us(20);
	  SCL_mp=0;
   }
   SDA_AA_mp=1; 
   SCL_mp=1;
   delay_us(20);
//   if(SDA_IN_mp)
//   error_i|=0x02;
   SCL_mp=0;
}
void read_mp(u8 x_ack)
{
	u8 zz;
	v_mp=0;
	SDA_AA_mp=1;
   for(zz=0;zz<8;zz++)
   {
   	  SCL_mp=1;
	  v_mp<<=1;
		delay_us(20);
	  if(SDA_IN_mp)
	  v_mp++;	  
	  SCL_mp=0;
		delay_us(20);
   }
   SDA_AA_mp=!x_ack;
	 delay_us(20);
   SCL_mp=1;
   delay_us(20);
   SCL_mp=0;
}
void SAT_mp(void)									  
{
   SCL_mp=0;
   delay_us(20);
   SDA_AA_mp=1;
	 delay_us(20);
   SCL_mp=1;
   delay_us(20);						
   SDA_AA_mp=0;
   delay_us(20);
   SCL_mp=0;
   delay_us(20);
}
void SOP_mp(void)
{
   SCL_mp=0;
   delay_us(20);
   SDA_AA_mp=0;
   delay_us(20);
   SCL_mp=1;
   delay_us(20);
   SDA_AA_mp=1;
   delay_us(20);
}








