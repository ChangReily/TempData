#include "SHT2xx.h"
#include "at24c.h"
#include "X_02.h"

u16    crc0=0,crc1=0;
u32  v_SHT2,vv_SHT2;
float HUMIE=0,TEMP=0;

void SHT2X_int(void)
{
	SDA_sht=1;
	SCL_sht=1;
}
void SHT2X_EE(void)			 
{
		SHT2x(TEES_SHT);						             //����
		if(crc1!=crc0)
				error_i|=0x01;
		else
		{
				v_SHT2&=0xfffc;
				TEMP=v_SHT2*175.720/0x10000-46.85;
//				TEMP*=(0.1*TE_i);						//б������
//				TEMP+=TA_i;									//��ƫ��������
//				TEMP-=TC_i;									//��ƫ��������
//				TEMP*=100;									//�Ŵ�100��
//				TEMP_i=TEMP;
		} 							 
		SHT2x(HEES_SHT);				                 //��ʪ
		if(crc1!=crc0||!v_SHT2)
		{
				error_i|=0x01;
		}
		else
		{
				error_i&=0xfffE;   
				v_SHT2&=0xfffc;
				HUMIE=v_SHT2*125.0/0x10000-6;
				
//				HUMIE*=(0.1*HE_i);						//б������
//				HUMIE+=HA_i;									//��ƫ��������
//				HUMIE-=HC_i;									//��ƫ��������
				if(HUMIE<0)
					HUMIE=0;
				if(HUMIE>99.9)
					HUMIE=100;
//				HUMIE*=100;										//�Ŵ�100��
//				RH_i=HUMIE;
		}									
}
void SHT2x(u8 yi)						 
{  	
		u32 ii5;
		if(error_i&0x01)		 			   //���д������»���IIC��������SHT21
			soft_rest_sht();
		else			   
			SAT_sht();
		write_sht(ADDS_SHT+0);			//д
		write_sht(yi);
		SAT_sht();
		write_sht(ADDS_SHT+1);			//��
		SCL_sht=1;
		for(ii5=0;ii5<600;ii5++)						//��ʱ�ȴ��������
		{
			delay_ms(200);
			if(SCLA_sht)
			break;
		}
		if(SCLA_sht)
		{
			v_SHT2=0;
			read_sht(1);
			v_SHT2=vv_SHT2;
			v_SHT2<<=8;
			read_sht(1);
			v_SHT2+=vv_SHT2;
			crc1=0;   
			crc1^=v_SHT2;
			crc_8();
			read_sht(0);
			crc0=vv_SHT2;			   
		}  
		else
			crc1=!crc0;
		SOP_sht();  							    
}
void write_sht(u8 yii)							   
{
   u32 ii5;
   for(ii5=0x80;ii5>0;ii5>>=1)
   {
   	  if(yii&ii5)
	  SDA_sht=1;
	  else
	  SDA_sht=0;
	  delay_us(20);					   
	  SCL_sht=1;
	  delay_us(20);
	  SCL_sht=0;
	  delay_us(20);						
   }
   SDA_sht=1;
   delay_us(20);
   SCL_sht=1;
   delay_us(20);
//   if(SDAA_sht)
//	  error_i|=0x01;
   SCL_sht=0;
}
void read_sht(u8 x_ack)							
{
   u32 ii5;
   vv_SHT2=0; 
   SDA_sht=1;
   delay_us(20);
   for(ii5=0;ii5<8;ii5++)
   {   
      SCL_sht=1;
	  delay_us(20);
      vv_SHT2<<=1;
	  if(SDAA_sht)
	  vv_SHT2|=1;
	  SCL_sht=0;
	  delay_us(20);   	  							  		  	  
   }
   SDA_sht=!x_ack;
   delay_us(20);
   SCL_sht=1;
   delay_us(20);
   SCL_sht=0;
   delay_us(20);
   SDA_sht=1;
}
void SAT_sht(void)
{
   SCL_sht=0;
   delay_us(20);
   SDA_sht=1;
	 delay_us(20);
   SCL_sht=1;
   delay_us(20);						
   SDA_sht=0;
   delay_us(20);
   SCL_sht=0;
   delay_us(20);
}
void SOP_sht(void)
{
   SCL_sht=0;
   delay_us(20);
   SDA_sht=0;
   delay_us(20);
   SCL_sht=1;
   delay_us(20);
   SDA_sht=1;
   delay_us(20);
}	
void soft_rest_sht(void)
{
   u32 ii5;
   SAT_sht();
   SDA_sht=1;
   SCL_sht=0;
   delay_us(20);
   for(ii5=0;ii5<20;ii5++)
   {
   	  SCL_sht=1;
      delay_us(20);
      SCL_sht=0;
      delay_us(20);
   }					  
   if(error_i&0x02)							
   {
      write_sht(ADDS_SHT+0);
      write_sht(0xfe);
      SOP_sht();
      for(ii5=0;ii5<1000;ii5++)
      delay_us(20);
   }
   SAT_sht();
   error_i&=0xfffE;		   
}
void crc_8(void)								  
{					    
		u32 ii5;
		for(ii5=0;ii5<16;ii5++)
		{
			if(crc1&0x8000)
			{
				crc1<<=1;
				crc1^=0x3100;
			}
			else
				crc1<<=1;
		}	
		crc1>>=8;		   
}






















