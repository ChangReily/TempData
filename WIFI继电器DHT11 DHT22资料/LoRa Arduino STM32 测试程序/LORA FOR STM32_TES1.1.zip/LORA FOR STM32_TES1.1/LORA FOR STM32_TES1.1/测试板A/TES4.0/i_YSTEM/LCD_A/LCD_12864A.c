#include "LCD_12864A.h"
#include "X_02.h"

u8 i6x[16],i6xx[16];
u32 LEX=22,LEX_i=0,Dis_Mi=0,Dis_i=0,Dis_DO,SET_N,SET_Ni,SED_N,SED_Ni,SET_vi,SET_vii,SET_v2,Dis_SEEnum=0,Succeeded_i=0;
float SET_v4;
void LCD_int(void)
{
	u32 i602;
	RCC->APB2ENR|=1<<2;    	//ʹ��PORTAʱ�� ����PA14������� 2M .max
	GPIOA->CRH&=0XF0FFFFFF;	
	GPIOA->CRH|=0X02000000;
	
	RCC->APB2ENR|=1<<3;    	//ʹ��PORTBʱ��	����PB3~7 ������� 2M .max
	GPIOB->CRL&=0X00000FFF;	
	GPIOB->CRL|=0X22222000;
	////
	////
	delay_us(20);
	LEE=0;
	SCK6=0;
	SID6=0;
	CS6=0;
	EST6=0;
	delay_us(20);
	EST6=1;
	delay_ms(40);
	for(i602=0;i602<12;i602++)
	{
	   wr_lcd(0,table_LCDinit[i602],0);
	   delay_us(20);
	}
	Dis_clear();
	CS6=1;
	Dis_i=0;
	Dis_Mi=1;
}
//////////////////////////////////////////////////////////////////
void Dis_MM(u32 Dis_x)
{
	u32 i32;
		switch(Dis_x)
		{
			case 1:Dis_XSET(SET_N);break;
			case 2:Dis_XXSET(SET_N,SED_N,SET_v2,SET_v4);break;
			case 3:Dis_SUCCEEDED_(8,2,16,3,1);break;
			case 4:Dis_ERROR_(8,2,32,3,1);break;
			default:Dis_i=0;Dis_M();break;
		}
}
void Dis_M(void)
{
	if(Dis_Mi)	
	{
		Dis_Mi=0;
		Dis_clear();
		Display_any(128,2,0,0,0,0,1,1);
		Dis_sensor_(8,1,0,6,0);
		Dis_offset_(8,1,0,7,0);
	}
			Dis_MD_(16,2,2,0,1);	
			if(!CC)
			{
				Display_any(128,4,0,2,0,0,1,0);
				Dis_num(16,4,127-16*4,2,0,5,SENSOR_v,0);
			}
			else//�ؿ�
			{
				Display_any(16,2,0,4,2,2,1,0);//C
				Display_any(16,2,16,4,2,31,1,0);//:
				Dis_Num(8,1,16*2,5,0,2,CCx7+1,1);//00 CCx				
				Dis_num(16,4,127-16*4,2,0,5,SENSOR_v2[CCx],0);
			}
			Dis_Num(8,1,8*14,6,0,7,SENSOR_c,0);
			Dis_Num(8,1,8*14,7,0,7,SENSOR_i,0);
			////
			////
}
void Dis_XSET(u32 SET_Nx)
{
	u32 ii602,ii604;
	if(Dis_Mi)	
	{
		Dis_Mi=0;
		Dis_clear();
		Display_any(128,2,0,0,0,0,1,1);
		for(ii602=0;ii602<16;ii602++)
		{
			i6x[ii602]=0;
			i6xx[ii602]=0;
		}
		i6x[SET_Nx]=1;
	}
	////
					Dis_MD_SET(16,2,2,0,1);
					Dis_ZERO(8,1,8,2,i6x[0]);
					Dis_VSET(8,1,8,3,i6x[1]);		
					Dis_LED(8,1,8,4,i6x[2]);
					Dis_BUS(8,1,8,5,i6x[3]);
	////
	for(ii602=0;ii602<4;ii602++)
	{
		Display_any(8,1,0,ii602+2,2,30,0,i6x[ii602]);//*
	}		
	if(Dis_SEEnum)
	Display_any(128,1,0,SET_Nx+2,0,0,1,0);
}
void Dis_XXSET(u32 SET_Nx,u32 SED_Nx,u32 SET_vx2,float SET_vx4)
{
	if(Dis_Mi)	
	{
		Dis_Mi=0;
		Dis_clear();
		Display_any(128,2,0,0,0,0,1,1);		
	}		
	Dis_MDXSET(SET_Nx,SED_Nx,SET_vx2,SET_vx4);//F_SET	
}
////
////
void Dis_MDXSET(u32 SET_Nx,u32 SED_Nx,u32 SET_vx2,float SET_vx4)
{
	switch(SET_Nx)
	{
		case 0:
		{
			Dis_MD_ZERO(16,2,2,0,1);
			Dis_E_(16,2,0,6,0);//��ǰֵE:
			Dis_num(8,4,127-16*4,2,0,8,SENSOR_Ai,1);//ƫ����
			Dis_num(8,2,127-16*2,6,0,8,SENSOR_c,0);//ʵʱֵ
		}
		break;
		case 1:
		{
			Dis_MD_VSET(16,2,2,0,1);
			Dis_E_(16,2,0,6,0);//��ǰֵE:
			Dis_num(8,4,127-16*4,2,0,8,SET_vx4,1);
			Dis_num(8,2,127-16*2,6,0,8,SENSOR_v,0);
			if(Dis_SEEnum)//��Ӧλ��˸
			{
				if(SED_Nx>1)
				Display_any(8,4,127-16*4-(SED_Nx+1)*8,2,0,0,1,0);
				else
				Display_any(8,4,127-16*4-SED_Nx*8,2,0,0,1,0);	
			}
		}
		break;
		default:SET_Nx=0;break;
	}
}
////
////
////
////
void Dis_WELCOME_(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<10;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_WELCOME_[n0],0,da_x0);	
	}
}
////
////
void Dis_SUCCEEDED_(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<10;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_SUCCEEDED_[n0],0,da_x0);	
	}
}
////
////
void Dis_ERROR_(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<7;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_ERROR_[n0],0,da_x0);	
	}
}
void Dis_BYE_(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<4;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_BYE_[n0],0,da_x0);	
	}
}
////
void Dis_LED(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<3;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_LED_[n0],0,da_x0);	
	}
}
////
void Dis_BUS(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<3;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_BUS_[n0],0,da_x0);	
	}
}
////
////
////
////
////
//////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
////
////
void Dis_E_(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<2;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_E_[n0],0,da_x0);	
	}
}
////
////
void Dis_MD_VSET(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<7;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_MD_VSET[n0],0,da_x0);	
	}
}
////
////
void Dis_MD_ZERO(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<7;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_MD_ZERO[n0],0,da_x0);	
	}
}
////
////
void Dis_MD_SET(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<6;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_MD_SET[n0],0,da_x0);	
	}
}
////
////

////
////
////
////
void Dis_ZERO(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<4;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_ZERO[n0],0,da_x0);	
	}
}
////
////
void Dis_VSET(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<4;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_VSET[n0],0,da_x0);	
	}
}
////
////
////
////
////
////
////
////
////
////
void Dis_MDSET(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<4;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_MDSET[n0],0,da_x0);	
	}
}

void Dis_MD_(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	for(n0=0;n0<3;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_MD_[n0],0,da_x0);	
	}
}
////
////
////
////
void Dis_CC(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	Display_any(xi6,yi6,xii6,yii6,0,table_CC[0],0,da_x0);	
}
////
////
void Dis_sensor_(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	Display_any(xi6,yi6,xii6,yii6,2,table_sensor_[0],0,da_x0);
	for(n0=1;n0<6;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,1,table_sensor_[n0],0,da_x0);	
	}
	Display_any(xi6,yi6,xii6+xi6*n0,yii6,2,table_sensor_[n0],0,da_x0);
}
////
////
void Dis_offset_(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 n0;
	Display_any(xi6,yi6,xii6,yii6,2,table_offset_[0],0,da_x0);
	for(n0=1;n0<6;n0++)
	{
		Display_any(xi6,yi6,xii6+xi6*n0,yii6,1,table_offset_[n0],0,da_x0);	
	}
	Display_any(xi6,yi6,xii6+xi6*6,yii6,2,table_offset_[6],0,da_x0);
}
////////////////////////////////////////////////
////////////////////////////////////////////////
void Dis_Num(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0,u8 da_c,float data_f,u8 da_i)
{
	u32 ii200,ii202,ii203,ii204,ii205;
	u32 data_4;
	data_4=fabs((float)data_f);//ȡdata_f����ֵ
	if(data_f<0)
	{
		ii204=0;
	}
	else
	{
		ii204=1;
	}
		ii200=0;			
		ii205=1;
		for(ii202=1;ii202<10;ii202++)			//�ж�DATA��Ч����
		{
			if(data_4/ii205)
				ii200=ii202;
			ii205*=10;
		}
		if(!ii200)
			ii200=1;//��֤����һλ��ʾ
		ii205=0;
		for(ii202=0;ii202<ii200;ii202++)
		{			
			switch(ii202)
			{
				case 0:ii203=data_4%10;break;
				case 1:ii203=data_4%100/10;break;
				case 2:ii203=data_4%1000/100;break;
				case 3:ii203=data_4%10000/1000;break;
				case 4:ii203=data_4%100000/10000;break;
				case 5:ii203=data_4%1000000/100000;break;
				case 6:ii203=data_4%10000000/1000000;break;
				default:ii203=12;break;//12:�ո�
			}
			Display_any(xi6,yi6,xii6-xi6*ii205,yii6,0,ii203,0,da_x0);
			ii205++;
			if(ii205>=da_c)
			break;				
		}
		if(!ii204)
		{
			Display_any(xi6,yi6,xii6-xi6*ii205,yii6,0,11,0,da_x0);//11:-
			ii205++;
		}
		if(!da_i)
		{
			for(ii202=0;ii202<da_c-ii205;ii202++)
			{
				Display_any(xi6,yi6,xii6-xi6*ii205,yii6,0,12,0,da_x0);//�ո� ������Ч0
				ii205++;
			}
		}
}
////
////
void Dis_num(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0,u8 da_c,float data_f,u8 da_i)
{
	u32 ii200,ii202,ii203,ii204,ii205,ii206,da_c2;
	u32 data_4;
	data_f*=1000;
	data_4=fabs((float)data_f);//ȡdata_f����ֵ ���Ŵ�1000��
	if(data_f<0)
	{
		ii204=0;
	}
	else
	{
		ii204=1;
	}
		ii200=0;
		ii205=1000;
		if(!da_i)
		{
					/////////////////////////////////////////////ĩβ4��5��	
			for(ii202=1;ii202<10;ii202++)			//�ж�F0��Ч����
			{
				if(data_4/ii205)
					ii200=ii202;
				ii205*=10;
			}		
			switch(ii200)
			{
				case 0:if(data_4%10>4)data_4+=10;break;
				case 1:if(data_4%10>4)data_4+=10;break;
				case 2:if(data_4%100/10>4)data_4+=100;break;
				default:if(data_4%1000/100>4)data_4+=1000;break;
			}
					//////////////////////////////////////////////	
			ii200=0;			
			ii205=1000;
			for(ii202=1;ii202<10;ii202++)			//�ж�F2��Ч����
			{
				if(data_4/ii205)
					ii200=ii202;
				ii205*=10;
			}
			ii206=0;
			switch(ii200)
			{
				case 0:ii206=0;da_c2=4;break;
				case 1:ii206=0;da_c2=4;break;
				case 2:ii206=1;da_c2=4;break;
				case 3:ii206=3;da_c2=3;break;
				case 4:ii206=3;da_c2=4;break;
				case 5:ii206=3;da_c2=5;break;
				case 6:ii206=3;da_c2=6;break;
				default:ii206=3;da_c2=6;break;
			}
		}
		else
		{
			ii206=0;
			da_c2=da_c;
		}
		ii205=0;
		for(ii202=ii206;ii202<da_c2+ii206;ii202++)
		{			
			switch(ii202)
			{
				case 0:ii203=data_4%100/10;break;
				case 1:ii203=data_4%1000/100;break;
				case 2:ii203=10;break;
				case 3:ii203=data_4%10000/1000;break;
				case 4:ii203=data_4%100000/10000;break;
				case 5:ii203=data_4%1000000/100000;break;
				case 6:ii203=data_4%10000000/1000000;break;
				default:ii203=12;break;
			}
			Display_any(xi6,yi6,xii6-xi6*ii205,yii6,0,ii203,0,da_x0);
			ii205++;
			if(ii205>=da_c)
			break;				
		}
		if(!ii204)
		{
			Display_any(xi6,yi6,xii6-xi6*ii205,yii6,0,11,0,da_x0);//-
			ii205++;
			da_c-=1;
		}
		if(!da_i)
		{
			da_c-=da_c2;
			for(ii202=0;ii202<da_c;ii202++)
			{
				Display_any(xi6,yi6,xii6-xi6*ii205,yii6,0,12,0,da_x0);//�ո� ������Ч0
				ii205++;
			}
		}
}
////
void Dis_clear(void)
{
	Display_any(128,8,0,0,0,0,1,0);
}
//
void Display_any(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_i,u8 da_a,u8 dis_clear,u8 da_x0)
{
	u32 ii40,ii42,ii43,ii44,ii45,ii46,C_data,Z_data;
	u8 *da_g;
	u8 table_x[0xff];
	if(yii6<8)//����Χ  ����ʾ
	{
		switch(da_i)
		{
			case 3:
				{
					ii43=32/xi6;//X���ȱ���
					ii44=32/8/yi6;//Y�߶ȱ���
				}
				break;
			default:
				{
					ii43=16/xi6;//X���ȱ���
					ii44=32/8/yi6;//Y�߶ȱ���
				}
				break;
		}
		if(!dis_clear)
		{
			for(ii40=0;ii40<xi6*yi6;ii40++)
			{
				Z_data=0;
				for(ii42=0;ii42<8;ii42++)
				{
					C_data=0;
					for(ii45=0;ii45<ii43;ii45++)
					{
						for(ii46=0;ii46<ii44;ii46++)
						{
							
							switch(da_i)
							{
								case 0:
								{
									if(table_4[da_a][16*(ii44*(ii40/xi6)+ii42*ii44/8)+ii43*(ii40%xi6)+ii45]&(0x01<<(ii44*ii42%8+ii46)))
									C_data++;
								}
								break;
								case 1:
								{
									if(table_abc[da_a][16*(ii44*(ii40/xi6)+ii42*ii44/8)+ii43*(ii40%xi6)+ii45]&(0x01<<(ii44*ii42%8+ii46)))
									C_data++;
								}
								break;
								case 2:
								{
									if(table_ABC[da_a][16*(ii44*(ii40/xi6)+ii42*ii44/8)+ii43*(ii40%xi6)+ii45]&(0x01<<(ii44*ii42%8+ii46)))
									C_data++;
								}
								break;
								default:break;
							}					
						}				
					}
					if(C_data)
					if((ii43*ii44/C_data)<6)
					{
						Z_data|=(0x01<<ii42);
					}
				}
				table_x[ii40]=Z_data;
			}
		}
		else
		{
			table_x[0]=0;
		}	
		da_g=&table_x[0];
		for(ii40=0;ii40<yi6;ii40++)
		{
			wr_lcd(0,0xb0+ii40+yii6,0);//ҳ//7ҳ
			wr_lcd(0,0x10+xii6/0x10,0);//�и�4BIT//128��
			wr_lcd(0,0x00+xii6%0x10,0);//�е�4BIT
				for(ii42=0;ii42<xi6;ii42++)
			{
				 wr_lcd(1,*da_g,da_x0);
				 if(!dis_clear)
				 da_g++;
			}
		}
	}
}		
void LOGO(u8 xi6,u8 yi6,u8 xii6,u8 yii6,u8 da_x0)
{
	u32 ii40,ii42;
	u8 *da_g;
	u8 table_x[0xff];
	
	for(ii40=0;ii40<yi6;ii40++)
	{
		wr_lcd(0,0xb0+ii40+yii6,0);//ҳ//7ҳ
		wr_lcd(0,0x10+xii6/0x10,0);//�и�4BIT//128��
		wr_lcd(0,0x00+xii6%0x10,0);//�е�4BIT
		for(ii42=0;ii42<xi6;ii42++)
		{
			 wr_lcd(1,table_AAQ2[ii42+ii40*xi6],da_x0);
		}
	}
}
void W_NDATA(u8 xii6,u8 yii6,u8 da_i,u8 da_x0)//д��ҳ 8��1��
{
	wr_lcd(0,0xb0+yii6,0);//ҳ//7ҳ
	wr_lcd(0,0x10+xii6/0x10,0);//�и�4BIT//128��
	wr_lcd(0,0x00+xii6%0x10,0);//�е�4BIT
	wr_lcd(1,da_i,da_x0);
}
void wr_lcd(u8 a,u8 da_lcd,u8 da_x)
{
	u32 i40;
	CS6=0;
	
  RS6=!!a;
  if(a&&da_x)
		da_lcd^=0xff;	
	////
	////
	for(i40=0;i40<8;i40++)
	{
		SID6=!!(da_lcd&0x80);
		SCK6=1;
		SCK6=0;
		da_lcd<<=1;
	}
	CS6=1;
}








