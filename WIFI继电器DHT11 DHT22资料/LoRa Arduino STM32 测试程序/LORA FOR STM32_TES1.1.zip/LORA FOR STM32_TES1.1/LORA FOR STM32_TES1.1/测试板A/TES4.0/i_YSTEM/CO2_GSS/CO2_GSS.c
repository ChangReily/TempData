#include "sys.h"
#include "CO2_GSS.h"
#include "EE32.h"
#include "exti.h"
#include "at24c.h"
#include "X_02.h"
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//M2_vvi/��Ч����֡����ʱ�����ֵ��
//M2_i/����������ű�־��
//M2_ii/����������ű�־
//M2_v/��������λ�ο���־��
//M2_v2/��������λ�ο���־��
//M2_w/���Ϳ�ʼ��־,==1׼��,==2��ʼ��

u8  CO2_K,Aser_M0,M0_DATA,M0_writeDat,M0_readDat[M0_REN];
u32 M0_vvi,M0_c,M0_i,M0_ii,M0_v,M0_v2,M0_Ti,M0_Ri;				
float CO2_M0;

void M0_SRT_init(void)
{
	M0_RXN=1;
	M0_TX=1;
	
	CO2_K=0;
	Aser_M0=0;
	M0_vvi=0;
	M0_c=0;
	M0_i=0;
	M0_ii=0;
	M0_v=0;
	M0_v2=0;
	M0_Ti=0;
	M0_Ri=0;
}
void M0_CO2_GSS(void)
{
	if(CO2_K!=2)
		M0_AAT(ASC_K,2,1);		//MODE 2 POLL
	else
	{
		M0_AAT(ASC_Z,0,0);
		M0_AAR();
	}
}
void M0_AAT(u8 ASK_MX,u32 DATA_MX,u8 DATA_N)			//����һ������֡
{
	if(M0_Ti)
		{						
			if(!M0_v2)
			{
				switch(M0_ii)
				{				
					case 0:			//�������� X?
						{
							M0_writeDat=ASK_MX;
						}
						break;
					case 1:			//���Ϳո�� SPACE
						{
							M0_writeDat=ASC_space;
						}
						break;
					case 2:			//��������1
						{
							M0_writeDat=ASC_num+DATA_MX%10000/1000;
						}
						break;
					case 3:			//��������2
						{
							M0_writeDat=ASC_num+DATA_MX%1000/100;
						}
						break;
					case 4:			//��������3
						{
							M0_writeDat=ASC_num+DATA_MX%100/10;
						}
						break;
					case 5:			//��������4
						{
							M0_writeDat=ASC_num+DATA_MX%10;
						}
						break;
					case 6:			//����CR
						{
							M0_writeDat=ASC_CR;
						}
						break;
					case 7:			//����LF
						{
							M0_writeDat=ASC_LF;
						}
						break;
						default:break;
				}
			}
			switch(M0_v2)
			{
				case 0:			//9600/������ʼλ0
					{
						M0_TX=0;
					}
					break;
				case 4:			//9600/��������λ 0X01
					{
						if(M0_writeDat&0x01)
						M0_TX=1;
						else
						M0_TX=0;	
					}
					break;
				case 8:			//9600/��������λ 0X02
					{
						if(M0_writeDat&0x02)
						M0_TX=1;
						else
						M0_TX=0;	
					}
					break;
				case 12:			//9600/��������λ 0X04
					{
						if(M0_writeDat&0x04)
						M0_TX=1;
						else
						M0_TX=0;	
					}
					break;
				case 16:			//9600/��������λ 0X08
					{
						if(M0_writeDat&0x08)
						M0_TX=1;
						else
						M0_TX=0;	
					}
					break;
				case 20:			//9600/��������λ 0X10
					{
						if(M0_writeDat&0x10)
						M0_TX=1;
						else
						M0_TX=0;	
					}
					break;
				case 24:			//9600/��������λ 0X20
					{
						if(M0_writeDat&0x20)
						M0_TX=1;
						else
						M0_TX=0;	
					}
					break;
				case 28:			//9600/��������λ 0X40
					{
						if(M0_writeDat&0x40)
						M0_TX=1;
						else
						M0_TX=0;	
					}
					break;
				case 32:			//9600/��������λ 0X80
					{
						if(M0_writeDat&0x80)
						M0_TX=1;
						else
						M0_TX=0;	
					}
					break;
				case 36:			//9600/����ֹͣλ1
					{
						M0_TX=1;						
						M0_ii++;
						if(DATA_N&&M0_ii==2)
						{
							M0_ii=6-DATA_N;
						}
						if(M0_writeDat==ASC_LF)
						{
							M0_ii=0;
							M0_Ti=0;	
							M0_i=0;
							M0_c=0;
							Aser_M0=1;
							vvi405=0;
						}					
					}
					break;
				default:break;
			}
			if(M0_v2<64)
			M0_v2++;
			else
			M0_v2=0;	
		}
}
void M0_AAR(void)
{
	u32 x4;
	if(M0_Ri)
		{																																	
			M0_Ri=0;
			if(M0_readDat[0]==ASC_Z)
				CO2_M0=(M0_readDat[2]-ASC_num)*10000+(M0_readDat[3]-ASC_num)*1000+(M0_readDat[4]-ASC_num)*100+(M0_readDat[5]-ASC_num)*10+(M0_readDat[6]-ASC_num);
			if(M0_readDat[0]==ASC_K)
				CO2_K=M0_readDat[6]-ASC_num;
			for(x401=0;x401<M0_REN;x401++)
			{
				M0_readDat[x401]=0;
			}
			error_i&=0xfffB;
			Aser_M0=0;
			x404=1;
		}
		//////////////////////////////////
		if(M0_c)
		{
			switch(M0_v)
				{
					case 6:			//9600_OX01BIT
						{
							if(M0_RX)
							M0_DATA|=0x01;
						}
						break;
					case 10:			//9600_OX02BIT
						{
							if(M0_RX)
							M0_DATA|=0x02;
						}
						break;
					case 14:		//9600_OX04BIT
						{
							if(M0_RX)
							M0_DATA|=0x04;
						}
						break;
					case 18:		//9600_OX08BIT
						{
							if(M0_RX)
							M0_DATA|=0x08;
						}
						break;
					case 22:		//9600_OX10BIT
						{
							if(M0_RX)
							M0_DATA|=0x10;
						}
						break;
					case 26:		//9600_OX20BIT
						{
							if(M0_RX)
							M0_DATA|=0x20;
						}
						break;
					case 30:		//9600_OX40BIT
						{
							if(M0_RX)
							M0_DATA|=0x40;
						}
						break;
					case 34:		//9600_OX80BIT
						{
							if(M0_RX)
							M0_DATA|=0x80;
						}
						break;
					case 38:		//9600_ֹͣλ
						{
							M0_c=0;		//������ձ�־							
							if(M0_RX)
							{
								if(!M0_i||M0_readDat[0]==ASC_Z||M0_readDat[0]==ASC_K)
								{			
									M0_vvi=0;
									M0_readDat[M0_i]=M0_DATA;
									if(M0_readDat[M0_i]==ASC_LF)		//���һ������֡��ȡ 
									{
										M0_Ri=1;			//��λ֡������ɱ�־
									}
									if(M0_i<20)
									M0_i++;
								}		
							}
						}
						break;
						default:break;
				}
				if(M0_v<64)
				M0_v++;
				else
				M0_v=0;
		}
}
























