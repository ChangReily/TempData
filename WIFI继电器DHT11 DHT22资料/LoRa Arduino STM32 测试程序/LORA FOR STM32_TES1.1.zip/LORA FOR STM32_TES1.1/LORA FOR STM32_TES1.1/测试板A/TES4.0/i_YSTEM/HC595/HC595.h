#ifndef __HC595_H
#define __HC595_H
#include "sys.h"

#define DIN_H595 PAout(6)//HC595
//#define OE_H595  PEout(4)
#define LCK_H595 PAout(7)
#define SCK_H595 PBout(0)

void H595_int(void);
void H595(u32 data_xx);






















#endif



















