#ifndef __BMP085_H
#define __BMP085_H
#include "sys.h"
#include "math.h"


#define SDA_AA_mp 		EEOUT3	//IIC	SDA E3
#define SDA_IN_mp 		EEIN3
#define SCL_mp 				EEOUT4	//IIC SCL	E4
#define EOC_AA_mp 		EEOUT5	//ת��������־λ ����Ч E5
#define EOC_IN_mp 		EEIN5		//
#define XCLR_mp				EEOUT6  //��λ ����Ч E6

#define AM_C1 0xaaab
#define AM_C2 0xacad
#define AM_C3 0xaeaf
#define AM_C4 0xb0b1
#define AM_C5 0xb2b3
#define AM_C6 0xb4b5
#define AM_B1 0xb6b7
#define AM_B2 0xb8b9
#define AM_MB 0xbabb
#define AM_MC 0xbcbd
#define AM_MD 0xbebf
#define ADDRESS_mp 0xee
#define TEM_ 0x2e
#define LOWP_MODE 0x34
#define STAND_MODE 0x74
#define HRES_MODE 0xb4
#define UHRES_MODE 0xf4
#define oss_L 0
#define oss_S 1
#define oss_H 2
#define oss_U 3
#define REGIST_TES 0xf4
#define MSB_mp 0xf6
#define LSB_mp 0xf7
#define XLSB_mp 0xf8


void BMP085_init(void);				//��ʼ
void EEX_Pa(u8 im,u8 MODE_i,u8 oss_i);
void BMP085_xx(u8 MODE_,u8 osrs_);
void bmp_W(u8 address_i,u8 register_i,u8 data_i);			   //д�Ĵ�������һ��
void bmp_R(u8 address_i,u8 register_i,u8 data_ack);		   //���Ĵ�������һ��
void write_mp(u8 vvi_mp);
void read_mp(u8 x_ack);
void SAT_mp(void);
void SOP_mp(void);

extern u16 AC4_;
extern float T_z,Pa_i;












#endif

















